# RogueSquad

Rogue squad is a entity based monogame engine in development. Work is underway to clean it up, integrate work from my other networking and multiplayer code-bases, and begin work on making a simple ...rogue-like.. game.

## About
Rogue squad, like many of my projects, was hacked together in a few intense days of coding. That's left me with a fair bit of technical debt which I will be cleaning up ver the coming weeks. 

At it's core, the model of Systems, Components, Entities, and Nodes are sound and I've been able to attach them together in a variety of ways to create new features.

## Getting Started / Building
- Step 1: Download or pull from Git. 
- Step 2: Unzip the res/Content.7z to the /Content directory of either the DX or CrossPlatform project (or both)
- Step 3: Build!

## About Fonts
If you have any build errors related to /Content/Fonts/gamefont.spritefont or /Fonts/menufont.spritefont, open them up and make sure the font name is one supported by your system. You can try using Verdana which worked on my MAC/OSX build. 

## Next Up
Prior to the recent checkin's it's been a while since I've been actively developing on this prototype. As a result, I'm taking some time to make a list of all the improvements I'd like to make also taking the opportunity to go over the 'TODOs' in the code and knockout some Technical Debt. 
