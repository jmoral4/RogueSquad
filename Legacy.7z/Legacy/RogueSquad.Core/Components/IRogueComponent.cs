

namespace RogueSquad.Core.Components
{

    public interface IRogueComponent
    {
        ComponentTypes ComponentType { get; set; }
    }

}