﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RogueSquad.Core.Nodes
{
    public interface INode
    {
         int Id { get; set; }
    }
}
